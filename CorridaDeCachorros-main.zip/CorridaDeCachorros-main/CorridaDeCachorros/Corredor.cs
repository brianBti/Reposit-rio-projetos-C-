﻿using System;

namespace CorridaDeCachorros
{
    public class Corredor : BaseModel
    {
        private static readonly Random Random = new Random();

        private double _distanciaPercorrida { get; set; }
        public Posicoes Posicao { get; set; }
        public Racas Raca { get; set; }

        public Corredor(int posicaoCorredor, Racas raca) : base()
        {
            Nome = $"Corredor-{posicaoCorredor}";
            Raca = raca;
            BaseConstrutor();
        }

        public Corredor(string nomeCorredor, Racas raca) : base()
        {
            Nome = nomeCorredor;
            Raca = raca;
            BaseConstrutor();
        }

        private void BaseConstrutor()
        {
            _distanciaPercorrida = 0.0;
            Posicao = Posicoes.NaoGanho;
        }

        public virtual void Mover()
        {
            switch (Raca)
            {
                case Racas.Pitbull:
                    MoverPitbull();
                    break;
                case Racas.PastorAlemao:
                    MoverPastorAlemao();
                    break;
                case Racas.Pincher:
                    MoverPincher();
                    break;
                case Racas.Doberman:
                    MoverDoberman();
                    break;
                default:
                    break;
            }
        }

        private void MoverPitbull()
        {
            int distanciaPercorrida = Random.Next(3, 5);
            _distanciaPercorrida += (distanciaPercorrida * 0.1);
        }

        private void MoverPastorAlemao()
        {
            int distanciaPercorrida = Random.Next(0, 7);
            _distanciaPercorrida += (distanciaPercorrida * 0.1);
        }

        private void MoverPincher()
        {
            int distanciaPercorrida = Random.Next(2, 4);
            _distanciaPercorrida += (distanciaPercorrida * 0.1);
        }

        private void MoverDoberman()
        {
            int distanciaPercorrida = Random.Next(1, 6);
            _distanciaPercorrida += (distanciaPercorrida * 0.1);
        }

        public double DistanciaPercorrida()
        {
            return _distanciaPercorrida;
        }
    }
}
