﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CorridaDeCachorros
{
    public enum Racas
    {
        Pitbull = 0,
        PastorAlemao = 1,
        Pincher = 2,
        Doberman = 3
    }
}
