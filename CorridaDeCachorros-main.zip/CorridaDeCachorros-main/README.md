# Altera��es feitas corridaDeCachorros
-Em Corredor.cs:

*Atributo Raca adicionado:Foi adicionado um atributo Raca ao Corredor. Esse atributo � do tipo Racas, que � um enum que representa a ra�a do corredor.

*Construtores Atualizados:Os construtores foram atualizados para aceitar a ra�a como argumento e atribu�-la ao novo atributo Raca.

*M�todo Mover Atualizado:O m�todo Mover foi atualizado para utilizar a propriedade "Raca" ao inv�s de um argumento n�o existente chamado corredor.

-Em CorridaDeCachorro.cs:

*M�todo AdicionarCorredor Atualizado:

*O m�todo AdicionarCorredor foi atualizado para aceitar a ra�a do corredor como segundo argumento. 
Isso � necess�rio para criar um novo corredor utilizando o construtor adequado.


*M�todo AdicioneCorredores Atualizado: ao chamar AdicionarCorredor, agora passamos dois argumentos: 
o nome do cachorro e a ra�a. Isso resolve o erro que estava ocorrendo.

-Arquivo de Raca.cs adicionado para armazenar o enum contendo as ra�as.
