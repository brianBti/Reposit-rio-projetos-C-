﻿using System;
using System.Collections.Generic;

namespace CorridaDeCachorros
{
    public class CorridaDeCachorro
    {
        private const int NumeroMinimoDeApostadores = 5;
        private const int NumeroMinimoDeCorredores = 4;

        private bool primeiroCorredorChegou = false;
        private bool segundoCorredorChegou = false;
        private bool terceiroCorredorChegou = false;

        public double ValorTotalDeApostas { get; private set; } = 0.0;
        public List<Apostador> Apostadores { get; } = new List<Apostador>();
        public List<Corredor> Corredores { get; } = new List<Corredor>();

        public Corredor Primeiro { get; private set; }
        public Corredor Segundo { get; private set; }
        public Corredor Terceiro { get; private set; }

        public Premio PrimeiroPremio { get; private set; }
        public Premio SegundoPremio { get; private set; }
        public Premio TerceiroPremio { get; private set; }

        public CorridaDeCachorro(int numeroDeApostadores = 5, int numeroDeCorredores = 4)
        {
            ValidarQuantidadeMinima(numeroDeApostadores, numeroDeCorredores);

            InicializarApostadores(numeroDeApostadores);
            InicializarCorredores(numeroDeCorredores);
        }

        private void ValidarQuantidadeMinima(int numeroDeApostadores, int numeroDeCorredores)
        {
            if (numeroDeApostadores < NumeroMinimoDeApostadores)
            {
                throw new ArgumentException("No mínimo é permitido 5 apostadores.");
            }

            if (numeroDeCorredores < NumeroMinimoDeCorredores)
            {
                throw new ArgumentException("No mínimo é permitido 4 corredores.");
            }
        }

        private void InicializarApostadores(int numeroDeApostadores)
        {
            for (int i = 0; i < numeroDeApostadores; i++)
            {
                Apostadores.Add(new Apostador(i));
            }
        }

        private void InicializarCorredores(int numeroDeCorredores)
        {
            for (int i = 0; i < numeroDeCorredores; i++)
            {
                Corredores.Add(new Corredor(i));
            }
        }

        public void Apostar(Apostador apostador, Corredor corredor, double totalAposta)
        {
            ValidarAposta(apostador, totalAposta);

            ValorTotalDeApostas += totalAposta;
            apostador.CachorroApostado = corredor.Id;
            apostador.Saldo -= totalAposta;
        }

        private void ValidarAposta(Apostador apostador, double totalAposta)
        {
            if (apostador.Saldo < totalAposta)
            {
                throw new InvalidOperationException("Dinheiro insuficiente.");
            }
        }

        public void AdicionarApostador(Apostador apostador)
        {
            Apostadores.Add(apostador);
        }

        public void AdicionarCorredor(Corredor corredor)
        {
            Corredores.Add(corredor);
        }

        public void Apostar(string nomeApostador, string nomeCorredor, double totalAposta)
        {
            var apostador = Apostadores.Find(ap => ap.Nome.Equals(nomeApostador));
            var cachorroCorredor = Corredores.Find(cor => cor.Nome.Equals(nomeCorredor));

            Apostar(apostador, cachorroCorredor, totalAposta);
        }

        public bool Correr()
        {
            if (Apostadores.Count < NumeroMinimoDeApostadores)
            {
                Console.WriteLine("Apostadores insuficientes para iniciar a corrida.");
                return false;
            }

            if (Corredores.Count < NumeroMinimoDeCorredores)
            {
                Console.WriteLine("Corredores insuficientes para iniciar a corrida.");
                return false;
            }

            while (!primeiroCorredorChegou || !segundoCorredorChegou || !terceiroCorredorChegou)
                VerificarCorredoresEcorrer();

            return true;
        }

        public void DefinirPremioGanhadores()
        {
            DefinirPremio(Primeiro, Posicoes.Primeiro, 0.7);
            DefinirPremio(Segundo, Posicoes.Segundo, 0.2);
            DefinirPremio(Terceiro, Posicoes.Terceiro, 0.1);

            ExibirResultados();
        }

        private void DefinirPremio(Corredor corredor, Posicoes posicao, double percentualPremio)
        {
            var apostadoresGanhadores = Apostadores.FindAll(ap => ap.CachorroApostado.Equals(corredor.Id));
            var valorPremio = ValorTotalDeApostas * percentualPremio;

            switch (posicao)
            {
                case Posicoes.Primeiro:
                    PrimeiroPremio = new Premio(posicao, valorPremio, apostadoresGanhadores);
                    break;
                case Posicoes.Segundo:
                    SegundoPremio = new Premio(posicao, valorPremio, apostadoresGanhadores);
                    break;
                case Posicoes.Terceiro:
                    TerceiroPremio = new Premio(posicao, valorPremio, apostadoresGanhadores);
                    break;
            }
        }

        private void ExibirResultados()
        {
            Console.Clear();
            Console.WriteLine("Resultado da Corrida:");
            Console.WriteLine($"1º {Primeiro.Nome} lugar - Prêmio: R$ {PrimeiroPremio.ValorTotal.ToString("N2")}");
            Console.WriteLine($"2º {Segundo.Nome} lugar - Prêmio: R$ {SegundoPremio.ValorTotal.ToString("N2")}");
            Console.WriteLine($"3º {Terceiro.Nome} lugar - Prêmio: R$ {TerceiroPremio.ValorTotal.ToString("N2")}");

            ExibirVencedores(PrimeiroPremio.Apostadores, "Vencedores 1º lugar");
            ExibirVencedores(SegundoPremio.Apostadores, "Vencedores 2º lugar");
            ExibirVencedores(TerceiroPremio.Apostadores, "Vencedores 3º lugar");
        }

        private void ExibirVencedores(List<Apostador> apostadores, string mensagem)
        {
            Console.WriteLine($"{mensagem}:");
            foreach (var apostador in apostadores)
                Console.WriteLine($"{apostador.Nome}");

            Console.WriteLine("Pressione qualquer tecla para continuar...");
            Console.ReadKey();
        }

        private void VerificarCorredoresEcorrer()
        {
            foreach (var corredor in Corredores)
            {
                corredor.Mover();

                if (corredor.DistanciaPercorrida() >= 100.00)
                {
                    if (!primeiroCorredorChegou && !corredor.CruzouChegada)
                    {
                        AtualizarStatusCorredor(corredor, Posicoes.Primeiro);
                        continue;
                    }
                    if (!segundoCorredorChegou && !corredor.CruzouChegada)
                    {
                        AtualizarStatusCorredor(corredor, Posicoes.Segundo);
                        continue;
                    }
                    if (!terceiroCorredorChegou && !corredor.CruzouChegada)
                    {
                        AtualizarStatusCorredor(corredor, Posicoes.Terceiro);
                        continue;
                    }
                    corredor.Posicao = Posicoes.NaoGanho;
                }
            }
        }

        private void AtualizarStatusCorredor(Corredor corredor, Posicoes posicao)
        {
            corredor.Posicao = posicao;
            corredor.CruzouChegada = true;

            switch (posicao)
            {
                case Posicoes.Primeiro:
                    primeiroCorredorChegou = true;
                    Primeiro = corredor;
                    break;
                case Posicoes.Segundo:
                    segundoCorredorChegou = true;
                    Segundo = corredor;
                    break;
                case Posicoes.Terceiro:
                    terceiroCorredorChegou = true;
                    Terceiro = corredor;
                    break;
            }

            Console.Clear();
            Console.WriteLine($"{posicao} corredor a chegar:");
            Console.WriteLine(corredor.Nome);

            Console.WriteLine("Pressione qualquer tecla para continuar...");
            Console.ReadKey();
        }
    }
}
