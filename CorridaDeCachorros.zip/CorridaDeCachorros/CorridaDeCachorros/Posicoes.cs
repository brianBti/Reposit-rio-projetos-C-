﻿namespace CorridaDeCachorros;

public enum Posicoes
{
    NaoGanho = 0,
    Primeiro = 1,
    Segundo = 2,
    Terceiro = 3
}
