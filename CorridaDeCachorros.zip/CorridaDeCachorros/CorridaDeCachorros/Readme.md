# Corrida de cachorros SENAI

## Projeto teste, vamos fazer uma casa de apostas para corrida de cachorro
- Deve pedir quantos apostadores ter� a partida
- Todo apostador come�a com R$ 20,00 
- Deve ter no m�nimo 5 apostadores
- Deve informar quantos corredores ter� a casa de apostas
- Deve ter no m�nimo 4 corredores
- Os corredores podem mover aleatoriamente a cada rodada entre 10cm at� 60 cm
- Deve fazer com que cada apostador informe em qual corredor ele ir� apostar
- Ganha a corrida o corredor que chegar em 100 metros primeiro
- At� o terceiro colocado recebe pr�mio
- As premia��es s�o 70% para o primeiro, 20% para o segundo e 10% para o terceiro
- Deve dividir o premio para aqueles que apostaram no corredor
- Todos devem finalizar a corrida
- Deve mostrar ao finalizar a corrida- 
- Coloca��o dos corredores
- Quanto cada apostador tem de saldo
- Agora, queremos uma corrida dinamica e adicionar mais corredores 
- Um corredor que pode andar entre 0 cm  e 70 cm
- Outro que pode andar entre 30cm e 50cm 
- Outro que pode entre 20cm e 40cm
- Alterar para n�o mais criar apostadores din�micos, mas ter a op��o de adicionar os apostadores e indicar o nome de cada um.
- Alterar para n�o mais criar os corredores dinamicamente, mas ter a op��o de adicionar eles antes de iniciar a corrida.
- Criar um novo projeto em console para poder adicionar os apostadores e corredores, solicitar as apostas e rodar v�rias vezes a corrida antes digitar �exit�
- Se ninguem apostou no corredor, o dinheiro deve retornar para a casa de apostas