﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using CorridaDeCachorros;
using Xunit;
using FluentAssertions;

namespace CorridaDeCachorros.Tests
{
    [TestClass()]
    public class ApostadorTests
    {

        [Fact]
        public void Deve_Um_Apostador_Iniciar_Com_Saldo_De_Vinte()
        {
            //Arrange
            var saldoEsperado = 20;

            Apostador apostador;

            //Act
            apostador = new Apostador(1);

            //Assert
            apostador.Saldo.Should().Be(saldoEsperado);
        }

       

        [Fact]
        public void CorridaDeCachorroTest()
        {
            //Arrange
            CorridaDeCachorro corrida;

            //Act
            corrida = new CorridaDeCachorro(5, 4);

            //Assert
            corrida.Apostar(corrida.Apostadores[0], corrida.Corredores[0], 200.0);
            corrida.Correr();

            for (var corredor in corrida.Corredores)
            {
                
            }
        }
    }
}